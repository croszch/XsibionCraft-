package me.xsibioncraft;

import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public final class XsibionListener implements Listener {
    private final XsibionCraft plugin;
    private final XsibionGUI gui;
    private final DataManager data;
    private final Map<UUID, Long> cooldowns = new HashMap<>();

    private final int[] unlockCosts = {0, 100, 250, 500, 1000};
    private final int[] itemSlots = {10, 11, 12, 13, 14};

    public XsibionListener(XsibionCraft plugin, XsibionGUI gui, DataManager data) {
        this.plugin = plugin; this.gui = gui; this.data = data;
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player p)) return;
        String title = e.getView().getTitle();

        if (!title.startsWith(XsibionGUI.MAIN) && !title.startsWith(XsibionGUI.ITEMS)
                && !title.startsWith(XsibionGUI.CRAFTER) && !title.startsWith(XsibionGUI.RECIPE)) return;

        e.setCancelled(true);

        if (title.equals(XsibionGUI.MAIN)) {
            if (e.getRawSlot() == 11) gui.openItems(p);
            else if (e.getRawSlot() == 15) gui.openCrafter(p);
            return;
        }

        if (title.equals(XsibionGUI.ITEMS)) {
            for (int i = 0; i < 5; i++) {
                if (e.getRawSlot() == itemSlots[i] && !data.isSlotUnlocked(p, i)) {
                    if (data.unlockSlot(p, i, unlockCosts[i])) {
                        p.sendMessage("§aUnlocked Xsibion Slot " + (i + 1) + "!");
                        gui.openItems(p);
                    } else p.sendMessage("§cYou need " + unlockCosts[i] + " Arcana Points.");
                    return;
                }
            }
            return;
        }

        if (title.equals(XsibionGUI.CRAFTER)) {
            int slot = e.getRawSlot();
            int[] positions = {9,10,11,12,13,14,15};
            for (int i = 0; i < positions.length; i++) {
                if (slot == positions[i]) {
                    gui.openRecipe(p, XsibionItem.values()[i]);
                    return;
                }
            }
            return;
        }

        if (title.startsWith(XsibionGUI.RECIPE)) {
            if (e.getRawSlot() == 49) gui.openCrafter(p);
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        applyPassiveEffects(e.getPlayer());
        data.save();
    }

    public void applyPassiveEffects(Player p) {
        // These effects are intentionally modest and easy to balance.
        // Full 5-slot storage can be added next using a player data inventory.
    }
}
