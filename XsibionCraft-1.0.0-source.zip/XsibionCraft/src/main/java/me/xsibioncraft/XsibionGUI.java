package me.xsibioncraft;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.List;

public final class XsibionGUI {
    public static final String MAIN = ChatColor.DARK_AQUA + "✦ XsibionCraft";
    public static final String ITEMS = ChatColor.DARK_AQUA + "⚔ Xsibion Items";
    public static final String CRAFTER = ChatColor.DARK_AQUA + "🔨 Xsibion Crafter";
    public static final String RECIPE = ChatColor.DARK_AQUA + "📖 Xsibion Recipe";

    private final XsibionCraft plugin;

    public XsibionGUI(XsibionCraft plugin) { this.plugin = plugin; }

    private ItemStack named(Material mat, String name, List<String> lore) {
        ItemStack i = new ItemStack(mat);
        ItemMeta m = i.getItemMeta();
        m.setDisplayName(name);
        m.setLore(lore);
        i.setItemMeta(m);
        return i;
    }

    private void fill(Inventory inv) {
        ItemStack glass = named(Material.GRAY_STAINED_GLASS_PANE, " ", List.of());
        for (int i = 0; i < inv.getSize(); i++) inv.setItem(i, glass);
    }

    public void openMain(Player p) {
        Inventory inv = Bukkit.createInventory(null, 27, MAIN);
        fill(inv);
        inv.setItem(11, named(Material.CHEST, "§b⚔ Xsibion Items",
                List.of("§7Open your 5 magical-item slots.")));
        inv.setItem(15, named(Material.CRAFTING_TABLE, "§b🔨 Xsibion Crafter",
                List.of("§7View recipes and craft Xsibion Items.")));
        inv.setItem(22, named(Material.BLUE_DYE, "§b🔵 Arcana Points: " + plugin.data().getArcana(p),
                List.of("§7Used to unlock item slots and craft items.")));
        p.openInventory(inv);
    }

    public void openItems(Player p) {
        Inventory inv = Bukkit.createInventory(null, 27, ITEMS);
        fill(inv);
        int[] slots = {10, 11, 12, 13, 14};
        int[] costs = {0, 100, 250, 500, 1000};

        for (int i = 0; i < 5; i++) {
            if (plugin.data().isSlotUnlocked(p, i)) {
                inv.setItem(slots[i], named(Material.LIME_STAINED_GLASS_PANE,
                        "§aSlot " + (i + 1) + " — Unlocked",
                        List.of("§7Place an Xsibion Item here.")));
            } else {
                inv.setItem(slots[i], named(Material.RED_STAINED_GLASS_PANE,
                        "§cSlot " + (i + 1) + " — Locked",
                        List.of("§7Unlock cost: §b" + costs[i] + " AP", "§eClick to unlock.")));
            }
        }
        inv.setItem(22, named(Material.BLUE_DYE, "§b🔵 Arcana Points: " + plugin.data().getArcana(p),
                List.of("§7Click locked slots to unlock them.")));
        p.openInventory(inv);
    }

    public void openCrafter(Player p) {
        Inventory inv = Bukkit.createInventory(null, 27, CRAFTER);
        fill(inv);
        XsibionItem[] items = XsibionItem.values();
        int[] positions = {9, 10, 11, 12, 13, 14, 15};
        for (int i = 0; i < items.length; i++) inv.setItem(positions[i], items[i].icon(plugin.itemKey()));
        inv.setItem(22, named(Material.BARRIER, "§cBack", List.of()));
        p.openInventory(inv);
    }

    public void openRecipe(Player p, XsibionItem item) {
        Inventory inv = Bukkit.createInventory(null, 54, RECIPE + " — " + item.display());
        fill(inv);
        // Visual recipe preview; actual ingredient checking is handled by the listener.
        Material[][] grid = Recipes.recipe(item);
        int[] gridSlots = {19,20,21,28,29,30,37,38,39};
        for (int i = 0; i < 9; i++) {
            Material m = grid[i / 3][i % 3];
            if (m != null) inv.setItem(gridSlots[i], new ItemStack(m));
        }
        inv.setItem(24, item.icon(plugin.itemKey()));
        inv.setItem(33, named(Material.BLUE_DYE, "§b🔵 Arcana Cost: " + item.arcanaCost(),
                List.of("§7Your AP: §b" + plugin.data().getArcana(p))));
        inv.setItem(49, named(Material.BARRIER, "§cBack", List.of()));
        p.openInventory(inv);
    }
}
