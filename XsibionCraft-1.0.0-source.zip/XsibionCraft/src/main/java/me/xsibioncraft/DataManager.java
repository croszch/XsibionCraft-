package me.xsibioncraft;

import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.IOException;
import java.util.UUID;

public final class DataManager {
    private final XsibionCraft plugin;
    private final File file;
    private YamlConfiguration cfg;

    public DataManager(XsibionCraft plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "players.yml");
    }

    public void load() {
        if (!plugin.getDataFolder().exists()) plugin.getDataFolder().mkdirs();
        cfg = YamlConfiguration.loadConfiguration(file);
    }

    public void save() {
        try { cfg.save(file); }
        catch (IOException e) { plugin.getLogger().severe("Could not save players.yml: " + e.getMessage()); }
    }

    private String path(Player p) { return "players." + p.getUniqueId(); }

    public int getArcana(Player p) { return cfg.getInt(path(p) + ".arcana", 0); }
    public void setArcana(Player p, int amount) { cfg.set(path(p) + ".arcana", Math.max(0, amount)); }

    public boolean isSlotUnlocked(Player p, int slot) {
        if (slot == 0) return true;
        return cfg.getBoolean(path(p) + ".slots." + slot, false);
    }

    public boolean unlockSlot(Player p, int slot, int cost) {
        if (isSlotUnlocked(p, slot)) return true;
        int ap = getArcana(p);
        if (ap < cost) return false;
        setArcana(p, ap - cost);
        cfg.set(path(p) + ".slots." + slot, true);
        save();
        return true;
    }
}
