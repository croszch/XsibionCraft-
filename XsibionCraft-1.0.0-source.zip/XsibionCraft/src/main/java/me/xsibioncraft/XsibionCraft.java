package me.xsibioncraft;

import org.bukkit.NamespacedKey;
import org.bukkit.plugin.java.JavaPlugin;

public final class XsibionCraft extends JavaPlugin {

    private DataManager data;
    private NamespacedKey itemKey;

    @Override
    public void onEnable() {
        itemKey = new NamespacedKey(this, "xsibion_item");
        data = new DataManager(this);
        data.load();

        XsibionGUI gui = new XsibionGUI(this);
        getCommand("xc").setExecutor((sender, command, label, args) -> {
            if (!(sender instanceof org.bukkit.entity.Player player)) {
                sender.sendMessage("Players only.");
                return true;
            }
            gui.openMain(player);
            return true;
        });

        getServer().getPluginManager().registerEvents(
                new XsibionListener(this, gui, data), this
        );

        getLogger().info("XsibionCraft enabled.");
    }

    @Override
    public void onDisable() {
        if (data != null) data.save();
    }

    public DataManager data() { return data; }
    public NamespacedKey itemKey() { return itemKey; }
}
