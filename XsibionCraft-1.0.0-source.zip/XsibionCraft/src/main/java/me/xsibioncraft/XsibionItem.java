package me.xsibioncraft;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.List;

public enum XsibionItem {
    WINDCALLER("Windcaller", Material.FEATHER, "Unleash a powerful gust that pushes nearby enemies away.", 25),
    GUARDIAN_SHIELD("Guardian Shield", Material.SHIELD, "Protects you with a temporary burst of damage resistance.", 30),
    PHOENIX_FEATHER("Phoenix Feather", Material.FEATHER, "When you're in danger, grants a powerful recovery effect.", 50),
    LIFEBLOOM("Lifebloom", Material.AMETHYST_SHARD, "Heal a nearby teammate with the power of life.", 35),
    STORMCORE("Stormcore", Material.NETHER_STAR, "Grants unlimited Haste while equipped.", 75),
    MOONSTONE("Moonstone", Material.AMETHYST_SHARD, "Blesses you with Speed and Night Vision while equipped.", 40),
    THORNCORE("Thorncore", Material.CACTUS, "Grants unlimited Thorns, reflecting damage back to attackers.", 50);

    private final String display;
    private final Material material;
    private final String description;
    private final int arcanaCost;

    XsibionItem(String display, Material material, String description, int arcanaCost) {
        this.display = display;
        this.material = material;
        this.description = description;
        this.arcanaCost = arcanaCost;
    }

    public int arcanaCost() { return arcanaCost; }
    public String display() { return display; }

    public ItemStack icon(NamespacedKey key) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(ChatColor.AQUA + "✦ " + display);
        meta.setLore(List.of(
                ChatColor.GRAY + description,
                "",
                ChatColor.BLUE + "🔵 Arcana Cost: " + arcanaCost
        ));
        meta.getPersistentDataContainer().set(key, PersistentDataType.STRING, name());
        item.setItemMeta(meta);
        return item;
    }

    public static XsibionItem from(ItemStack item, NamespacedKey key) {
        if (item == null || !item.hasItemMeta()) return null;
        String id = item.getItemMeta().getPersistentDataContainer().get(key, PersistentDataType.STRING);
        if (id == null) return null;
        try { return valueOf(id); } catch (IllegalArgumentException e) { return null; }
    }
}
