package me.xsibioncraft;

import org.bukkit.Material;

public final class Recipes {
    private Recipes() {}

    public static Material[][] recipe(XsibionItem item) {
        Material E = null;
        return switch (item) {
            case WINDCALLER -> new Material[][]{
                    {Material.FEATHER, Material.IRON_INGOT, Material.FEATHER},
                    {Material.IRON_INGOT, Material.WIND_CHARGE, Material.IRON_INGOT},
                    {Material.FEATHER, Material.IRON_INGOT, Material.FEATHER}};
            case GUARDIAN_SHIELD -> new Material[][]{
                    {Material.IRON_INGOT, Material.IRON_INGOT, Material.IRON_INGOT},
                    {Material.IRON_INGOT, Material.SHIELD, Material.IRON_INGOT},
                    {E, Material.AMETHYST_SHARD, E}};
            case PHOENIX_FEATHER -> new Material[][]{
                    {Material.BLAZE_POWDER, Material.GOLD_INGOT, Material.BLAZE_POWDER},
                    {Material.GOLD_INGOT, Material.TOTEM_OF_UNDYING, Material.GOLD_INGOT},
                    {Material.BLAZE_POWDER, Material.FEATHER, Material.BLAZE_POWDER}};
            case LIFEBLOOM -> new Material[][]{
                    {Material.GLOW_BERRIES, Material.GOLD_INGOT, Material.GLOW_BERRIES},
                    {Material.GOLD_INGOT, Material.HEART_OF_THE_SEA, Material.GOLD_INGOT},
                    {Material.GLOW_BERRIES, Material.GOLD_INGOT, Material.GLOW_BERRIES}};
            case STORMCORE -> new Material[][]{
                    {Material.COPPER_INGOT, Material.REDSTONE, Material.COPPER_INGOT},
                    {Material.REDSTONE, Material.DIAMOND, Material.REDSTONE},
                    {Material.COPPER_INGOT, Material.REDSTONE, Material.COPPER_INGOT}};
            case MOONSTONE -> new Material[][]{
                    {Material.QUARTZ, Material.AMETHYST_SHARD, Material.QUARTZ},
                    {Material.AMETHYST_SHARD, Material.GLOWSTONE, Material.AMETHYST_SHARD},
                    {Material.QUARTZ, Material.AMETHYST_SHARD, Material.QUARTZ}};
            case THORNCORE -> new Material[][]{
                    {Material.CACTUS, Material.IRON_INGOT, Material.CACTUS},
                    {Material.IRON_INGOT, Material.EMERALD, Material.IRON_INGOT},
                    {Material.CACTUS, Material.IRON_INGOT, Material.CACTUS}};
        };
    }
}
