# XsibionCraft

A Paper Minecraft plugin concept with:

- `/xc` main GUI
- Xsibion Items menu
- Xsibion Crafter recipe browser
- 7 magical items
- Arcana Points
- 5 equipment slots
- Slot unlock costs
- Custom item identifiers using PersistentDataContainer

## Target

Paper 1.21.11 / Java 21.

## Important

This starter implementation includes the GUI, item definitions, recipes, Arcana storage, and slot unlocking framework. The next development step is wiring the 5 equipment slots to persistent per-player item storage and implementing every item's live ability/cooldown.

For a truly custom visual icon, a Minecraft resource pack is required; the plugin can then assign custom model/item data to each Xsibion item.
